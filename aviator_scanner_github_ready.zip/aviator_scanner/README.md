# Aviator Scanner — Android starter v0.1.0

Projeto inicial para compilação de um APK de demonstração via GitHub Actions, sem precisar de computador local.

## O que esta versão faz
- Abre uma tela Android em tema escuro.
- Solicita consentimento explícito do Android para iniciar uma sessão de captura de tela.
- Exibe uma notificação enquanto o serviço de captura estiver ativo.
- Permite interromper a sessão pelo próprio aplicativo.

## O que ainda NÃO faz
- Ainda não implementa VirtualDisplay/ImageReader nem OCR.
- Ainda não extrai multiplicadores automaticamente e não envia dados ao painel web.
- Não acessa contas, senhas, apostas ou APIs privadas do site.
- Não prevê resultados futuros.

A captura de tela é apenas um esqueleto técnico: antes de processar imagens, será necessário implementar o pipeline de frames, recortar somente a área de histórico e fazer OCR local, com testes em diferentes tamanhos de tela. Use somente quando permitido pelo operador do jogo e respeite os avisos de privacidade do Android.

## Compilar pelo celular usando GitHub
1. No Android, abra github.com e entre na sua conta.
2. Crie um repositório chamado `aviator-scanner`. Pode deixá-lo **Private**.
3. Envie todos os arquivos e pastas deste pacote para a raiz do repositório, mantendo os caminhos.
4. Abra a aba **Actions** do repositório e habilite workflows, se o GitHub solicitar.
5. Execute **Build Aviator Scanner APK** em **Run workflow**. Um push na branch `main` ou `master` também inicia a compilação.
6. Quando terminar com status verde, abra a execução e baixe `aviator-scanner-debug-apk` em **Artifacts**.
7. Extraia o ZIP baixado e instale `app-debug.apk`. O Android poderá pedir autorização para instalar apps dessa origem.

## Requisitos técnicos
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- Android compileSdk 35 / minSdk 26

O APK gerado é de depuração, não assinado para publicação na Play Store.
