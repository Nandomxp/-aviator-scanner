package com.aviatorscanner

import android.app.*
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.content.Context

/** Base de serviço. A próxima etapa implementará VirtualDisplay + ImageReader + OCR local. */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> {
                createNotificationChannel()
                startForeground(NOTIFICATION_ID, Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Aviator Scanner")
                    .setContentText("Captura de tela autorizada em andamento")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .build())
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, ActivityResult.RESULT_CANCELED)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                if (data != null) {
                    val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = manager.getMediaProjection(code, data)
                    projection?.registerCallback(object : MediaProjection.Callback() {
                        override fun onStop() { stopCapture() }
                    }, null)
                    // TODO: Criar VirtualDisplay/ImageReader e processar somente a região do histórico.
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun stopCapture() {
        projection?.stop(); projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Captura de tela", NotificationManager.IMPORTANCE_LOW))
        }
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.aviatorscanner.START"
        const val ACTION_STOP = "com.aviatorscanner.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val CHANNEL_ID = "aviator_capture"
        const val NOTIFICATION_ID = 41
    }
}

private object ActivityResult { const val RESULT_CANCELED = 0 }
