package com.aviatorscanner

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val captureConsent = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            startForegroundService(service)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var status by remember { mutableStateOf("Aguardando autorização") }
            MaterialTheme(colorScheme = darkColorScheme(
                background = Color(0xFF101010), surface = Color(0xFF1B1B1F), primary = Color(0xFFEF233C)
            )) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF101010)) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("AVIATOR SCANNER", color = Color(0xFFEF233C), style = MaterialTheme.typography.headlineSmall)
                        Text("Captura de tela autorizada", color = Color.White)
                        Text(status, color = Color.LightGray)
                        Button(onClick = {
                            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            captureConsent.launch(manager.createScreenCaptureIntent())
                            status = "Aguardando sua autorização do Android"
                        }) { Text("Iniciar captura") }
                        OutlinedButton(onClick = {
                            startService(Intent(this@MainActivity, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
                            status = "Captura interrompida"
                        }) { Text("Parar captura") }
                        Text("Protótipo: o reconhecimento OCR e a sincronização ainda não foram implementados.", color = Color.Gray)
                    }
                }
            }
        }
    }
}
